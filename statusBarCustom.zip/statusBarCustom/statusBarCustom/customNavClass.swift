//
//  customNavClass.swift
//  statusBarCustom
//
//  Created by Muhammad Hamza Mustafa on 11/12/2021.
//

import Foundation
import UIKit

final class customNavClass : UINavigationController {
    override var childForStatusBarStyle: UIViewController? {
        topViewController
    }
}
