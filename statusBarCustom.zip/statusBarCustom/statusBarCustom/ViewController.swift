//
//  ViewController.swift
//  statusBarCustom
//
//  Created by Muhammad Hamza Mustafa on 11/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    
// ----------- First Way Programmatically for specific VC
    
///    for changing tint color to white
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        .lightContent
//    }

///   for changing tint color to black
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        .darkContent
//    }

    
// ------------  Second Way Via Info.plist to apply on all views
// goto info.plist , add property (View controller-based status bar appearance) set to NO
// than goto project target - generals - set property for Status bar directly
    
    
// ------------ Third way use extension
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationController?.setStatusBar(backgroundColor: UIColor.yellow)
        self.navigationController?.navigationBar.setNeedsLayout()
    }
}

extension UINavigationController {
    func setStatusBar(backgroundColor: UIColor) {
        let statusBarFrame: CGRect
        if #available(iOS 13.0, *) {
            statusBarFrame = view.window?.windowScene?.statusBarManager?.statusBarFrame ?? CGRect.zero
        } else {
            statusBarFrame = UIApplication.shared.statusBarFrame
        }
        let statusBarView = UIView(frame: statusBarFrame)
        statusBarView.backgroundColor = backgroundColor
        view.addSubview(statusBarView)
    }
}
